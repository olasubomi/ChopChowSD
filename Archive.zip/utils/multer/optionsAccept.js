let multerOptionsToAcceptIntstructionContent = [
    { name: 'mealImage' },
    { name: 'instructionChunkContent1' },
    { name: 'instructionChunkContent2' },
    { name: 'instructionChunkContent3' },
    { name: 'instructionChunkContent4' },
    { name: 'instructionChunkContent5' },
    { name: 'instructionChunkContent6' },
  ]

  module.exports= {
    multerOptionsToAcceptIntstructionContent,
  }