const { percentageCalculator } = require("./percentage-calculator");

module.exports = {
    percentageCalculator,
};
