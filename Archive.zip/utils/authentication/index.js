const isAuthenticated = require('./3.isAuthenticated');
const authunticationLogout = require('./authunticationLogout');

module.exports={
    isAuthenticated,
    authunticationLogout
}
